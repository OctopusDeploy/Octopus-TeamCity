# Changelog

## [2.30.0](https://github.com/OctopusDeploy/cli/compare/v2.29.0...v2.30.0) (2026-10-16)


### Features

* Support promoting to multiple environments ([#760](https://github.com/OctopusDeploy/cli/issues/760)) ([f3d6ab3](https://github.com/OctopusDeploy/cli/commit/f3d6ab314fac6060438b2ee24e543f8cc6e6d6ec))

## [2.29.0](https://github.com/OctopusDeploy/cli/compare/v2.28.0...v2.29.0) (2026-10-15)


### Features

* Add release promote command ([#749](https://github.com/OctopusDeploy/cli/issues/749)) ([c3c2e27](https://github.com/OctopusDeploy/cli/commit/c3c2e272fdf5f4414e05ade848895453e6ea109a))


### Bug Fixes

* Return errors from NewDependencies instead of panicking ([#756](https://github.com/OctopusDeploy/cli/issues/756)) ([82f7bc9](https://github.com/OctopusDeploy/cli/commit/82f7bc988b33bbe73166c64ba3900d12528fc45c))

## [2.28.0](https://github.com/OctopusDeploy/cli/compare/v2.27.1...v2.28.0) (2026-10-14)


### Features

* add task list command ([b02e2b0](https://github.com/OctopusDeploy/cli/commit/b02e2b0c943eceba6bec37a910f51a1849d08143))


### Bug Fixes

* **deps:** bump github.com/bmatcuk/doublestar/v4 from 4.10.0 to 4.10.2 ([976ebc9](https://github.com/OctopusDeploy/cli/commit/976ebc9db210bbf7b076489de90781e19f8b4929))
* **deps:** bump golang.org/x/term ([2232beb](https://github.com/OctopusDeploy/cli/commit/2232bebff3af0e31a2e236bb1ea3559834a22ab6))
* scope task list to the current space ([6ccb5aa](https://github.com/OctopusDeploy/cli/commit/6ccb5aa3696e6df282eac8be431a9081b0e47c73))
* surface real errors from environment lookups in task list ([712a4cb](https://github.com/OctopusDeploy/cli/commit/712a4cb5712a66e25db4a4b43839c93eccc1d53f))
* use a large page size for task list --limit 0 ([951be21](https://github.com/OctopusDeploy/cli/commit/951be21bdcfdc7343d2ca0ab24435058c245223b))

## [2.27.1](https://github.com/OctopusDeploy/cli/compare/v2.27.0...v2.27.1) (2026-10-13)


### Bug Fixes

* Support lowercase legacy aliases ([#745](https://github.com/OctopusDeploy/cli/issues/745)) ([38a413d](https://github.com/OctopusDeploy/cli/commit/38a413d39ae6e45646d926c01f66e85872f1d089))
* Update to go 1.26.9 ([#746](https://github.com/OctopusDeploy/cli/issues/746)) ([b40b98d](https://github.com/OctopusDeploy/cli/commit/b40b98d5dcfff99f8ea669aa24d36b167f4c476d))

## [2.27.0](https://github.com/OctopusDeploy/cli/compare/v2.26.0...v2.27.0) (2026-10-02)


### Features

* add snapshot-variables commands for releases and runbook snapshots ([#738](https://github.com/OctopusDeploy/cli/issues/738)) ([e429d4d](https://github.com/OctopusDeploy/cli/commit/e429d4d560a0e9152b271058b884839e4dae76ac))

## [2.26.0](https://github.com/OctopusDeploy/cli/compare/v2.25.1...v2.26.0) (2026-09-16)


### Features

* add project metadata to project list and view ([33c97f5](https://github.com/OctopusDeploy/cli/commit/33c97f5236825e9fa71f18b9b373f1fe8a4e8836)), closes [#491](https://github.com/OctopusDeploy/cli/issues/491)


### Bug Fixes

* don't panic when a version controlled project has no git settings ([ba91025](https://github.com/OctopusDeploy/cli/commit/ba91025f4570c157ba858657eac068515a754b7f))
* don't print an empty project group or lifecycle label in basic view ([9fb826e](https://github.com/OctopusDeploy/cli/commit/9fb826ea876fa292b2cfb47ef0de868d5757457f))
* don't print an empty version control branch label in basic view ([bbae421](https://github.com/OctopusDeploy/cli/commit/bbae4213324824c7386b55619415c3d8deb4d70e))
* honour project view --web for every output format ([7a258ff](https://github.com/OctopusDeploy/cli/commit/7a258ff09ebbddb7b0070041d6f37f0468ef58dd))


### Performance Improvements

* skip the name lookups for project list -f basic ([5ee2786](https://github.com/OctopusDeploy/cli/commit/5ee278623193fdf1c78e384c6385a84efc1864bc))

## [2.25.1](https://github.com/OctopusDeploy/cli/compare/v2.25.0...v2.25.1) (2026-09-09)


### Bug Fixes

* stop login --ignore-ssl-errors panicking on a wrapped transport ([#726](https://github.com/OctopusDeploy/cli/issues/726)) ([3860c0c](https://github.com/OctopusDeploy/cli/commit/3860c0cfbeb379d2484d80aa5164d517b4578005))

## [2.25.0](https://github.com/OctopusDeploy/cli/compare/v2.24.1...v2.25.0) (2026-09-01)


### Features

* Include and exclude targets by tag for deployments and runbook runs ([#585](https://github.com/OctopusDeploy/cli/issues/585)) ([2922f08](https://github.com/OctopusDeploy/cli/commit/2922f08f6be519883f222e42491064f5e234b872))

## [2.24.1](https://github.com/OctopusDeploy/cli/compare/v2.24.0...v2.24.1) (2026-08-25)


### Features

* Add --priority to release deploy and runbook run ([#708](https://github.com/OctopusDeploy/cli/issues/708)) ([c7c958f](https://github.com/OctopusDeploy/cli/commit/c7c958f07b066519ebe555e6dbf165b124b33a20))

## [2.24.0](https://github.com/OctopusDeploy/cli/compare/v2.23.10...v2.24.0) (2026-08-19)


### Features

* add channel list, view, and delete commands ([f3baf2c](https://github.com/OctopusDeploy/cli/commit/f3baf2c2641347ab3d82e20813e3b345b3642f83))
* show lifecycle names in channel list ([bf27551](https://github.com/OctopusDeploy/cli/commit/bf27551d93fbf0dd71158f7681dffaebc0e03acb))


### Bug Fixes

* bump Go to 1.26.6 to clear stdlib CVEs ([2b7449f](https://github.com/OctopusDeploy/cli/commit/2b7449f3f7504d9169801398d1a3a719c6206b4e))
* resolve the project in release progression allow and prevent ([afbff88](https://github.com/OctopusDeploy/cli/commit/afbff8860c54d3e45adbde0328b6811ce9c5358b))
* stop deployment target commands crashing for AWS ECS targets ([898a953](https://github.com/OctopusDeploy/cli/commit/898a9531f8f5b12845fb262c768723166060cafe))
* stop worker commands crashing on unreported endpoint details ([6e7e08c](https://github.com/OctopusDeploy/cli/commit/6e7e08c8ab497266c0802ad21eb5331e881bcc03))

## [2.23.10](https://github.com/OctopusDeploy/cli/compare/v2.23.9...v2.23.10) (2026-08-12)


### Bug Fixes

* **deps:** bump github.com/bmatcuk/doublestar/v4 from 4.4.0 to 4.10.0 ([933ecc2](https://github.com/OctopusDeploy/cli/commit/933ecc21dd668c6ea4aee6b0ce3db9a3e2812369))
* **deps:** bump github.com/OctopusDeploy/go-octopusdeploy/v2 ([372ff55](https://github.com/OctopusDeploy/cli/commit/372ff554c135ffe2ff9e327e22341e8c6bf72235))
* **deps:** bump github.com/spf13/cobra from 1.6.1 to 1.10.2 ([d041daf](https://github.com/OctopusDeploy/cli/commit/d041daf693419e30c12d8be76ec0723087705211))

## [2.23.9](https://github.com/OctopusDeploy/cli/compare/v2.23.8...v2.23.9) (2026-08-11)


### Bug Fixes

* always write a nuspec into generated NuGet packages ([5f2aeef](https://github.com/OctopusDeploy/cli/commit/5f2aeefc38a67d400e2b69bd582aa02cb29e0f7c))
* XML-escape values written into the nuspec ([e5a6f89](https://github.com/OctopusDeploy/cli/commit/e5a6f89795dc54c9663f08862ef46b8ba5b41a8b))

## [2.23.8](https://github.com/OctopusDeploy/cli/compare/v2.23.7...v2.23.8) (2026-08-07)


### Bug Fixes

* preserve --variable values through interactive runbook run ([#582](https://github.com/OctopusDeploy/cli/issues/582)) ([3d561d8](https://github.com/OctopusDeploy/cli/commit/3d561d86ab6da797cab3161375b82a3c02ea935a))

## [2.23.7](https://github.com/OctopusDeploy/cli/compare/v2.23.6...v2.23.7) (2026-08-06)


### Bug Fixes

* force-push the release branch and surface GitHub's error detail ([f428cb9](https://github.com/OctopusDeploy/cli/commit/f428cb9cc1f155120b02e16d911c2e5d69ed559d))
* open a pull request when publishing the homebrew formula ([c8e192d](https://github.com/OctopusDeploy/cli/commit/c8e192d32918827a102137add7d81711edfa5f30)), closes [#541](https://github.com/OctopusDeploy/cli/issues/541)

## [2.23.6](https://github.com/OctopusDeploy/cli/compare/v2.23.5...v2.23.6) (2026-08-06)


### Bug Fixes

* produce valid NuGet packages from package nuget create ([47932dc](https://github.com/OctopusDeploy/cli/commit/47932dc5a3f6a0ce02e24912610a9bc939f17191)), closes [#477](https://github.com/OctopusDeploy/cli/issues/477)

## [2.23.5](https://github.com/OctopusDeploy/cli/compare/v2.23.4...v2.23.5) (2026-08-05)


### Bug Fixes

* colour multi-line text one line at a time ([fd9d045](https://github.com/OctopusDeploy/cli/commit/fd9d04541f07092c9d999df46299e3185ed0e653))
* honour FORCE_COLOR=0, CLICOLOR_FORCE=0 and CLICOLOR=0 as colour off ([8282025](https://github.com/OctopusDeploy/cli/commit/82820258dca5781944b93b29d8a86219b3c8b6ee))
* support colour output in CI via FORCE_COLOR/CLICOLOR_FORCE ([3ecaa76](https://github.com/OctopusDeploy/cli/commit/3ecaa76056bf15104b6648372d7318e6c3380057)), closes [#506](https://github.com/OctopusDeploy/cli/issues/506)

## [2.23.4](https://github.com/OctopusDeploy/cli/compare/v2.23.3...v2.23.4) (2026-08-05)


### Bug Fixes

* **deps:** bump uuid, testify, viper and godotenv ([#645](https://github.com/OctopusDeploy/cli/issues/645)) ([151b469](https://github.com/OctopusDeploy/cli/commit/151b46977d4db6aa16631ea5aa405c07ffceb02e))

## [2.23.3](https://github.com/OctopusDeploy/cli/compare/v2.23.2...v2.23.3) (2026-08-05)


### Bug Fixes

* emit valid JSON from package create commands ([edf3e99](https://github.com/OctopusDeploy/cli/commit/edf3e99dd6fb2cb6e56ab9178009a1e91fe22738)), closes [#518](https://github.com/OctopusDeploy/cli/issues/518)

## [2.23.2](https://github.com/OctopusDeploy/cli/compare/v2.23.1...v2.23.2) (2026-08-05)


### Bug Fixes

* make delete commands usable with --no-prompt ([4f92fc4](https://github.com/OctopusDeploy/cli/commit/4f92fc4e28824a1406feb47e93750aa6c9bdc103)), closes [#490](https://github.com/OctopusDeploy/cli/issues/490) [#530](https://github.com/OctopusDeploy/cli/issues/530)

## [2.23.1](https://github.com/OctopusDeploy/cli/compare/v2.23.0...v2.23.1) (2026-08-05)


### Bug Fixes

* indent the --package escape example with spaces, not a tab ([45bcb30](https://github.com/OctopusDeploy/cli/commit/45bcb3037cc6db9facf3a41c348bfc355e7dd1fa))
* updated escape syntax docs on release create ([2b27030](https://github.com/OctopusDeploy/cli/commit/2b270306054a2bf70047de4335abf2529776852d))

## [2.23.0](https://github.com/OctopusDeploy/cli/compare/v2.22.1...v2.23.0) (2026-08-05)


### Features

* add --exclude to package create commands ([7e2aca9](https://github.com/OctopusDeploy/cli/commit/7e2aca9e18ed0c61bdc99eaaaa0a46ddd3e0b2b4)), closes [#214](https://github.com/OctopusDeploy/cli/issues/214)

## [2.22.1](https://github.com/OctopusDeploy/cli/compare/v2.22.0...v2.22.1) (2026-08-05)


### Bug Fixes

* **deps:** bump github.com/briandowns/spinner from 1.19.0 to 1.23.2 ([814d700](https://github.com/OctopusDeploy/cli/commit/814d70016f4d22ec879f2cc80f983ad92200a0ef))

## [2.22.0](https://github.com/OctopusDeploy/cli/compare/v2.21.6...v2.22.0) (2026-08-05)


### Features

* accept --tenant on tenant variables list ([406229d](https://github.com/OctopusDeploy/cli/commit/406229dd54f4eea114fc2ddb85dd625463188048)), closes [#297](https://github.com/OctopusDeploy/cli/issues/297)
* accept --tenant on tenant view ([d7e88b8](https://github.com/OctopusDeploy/cli/commit/d7e88b874d3af58262a52b50a6a1b888a6a8fa6d))
* prompt for a tenant when none is supplied to variables list ([a9e8db0](https://github.com/OctopusDeploy/cli/commit/a9e8db0b0fa8125b8aafb9d48cabb00af4838e8f))

## [2.21.6](https://github.com/OctopusDeploy/cli/compare/v2.21.5...v2.21.6) (2026-08-05)


### Bug Fixes

* stop commands crashing when an optional identifier is omitted ([b02f0df](https://github.com/OctopusDeploy/cli/commit/b02f0dfd5e04afbce773a13c80db7195aa4914fd)), closes [#627](https://github.com/OctopusDeploy/cli/issues/627)

## [2.21.5](https://github.com/OctopusDeploy/cli/compare/v2.21.4...v2.21.5) (2026-08-04)


### Bug Fixes

* bump Go to 1.26.5 and golang.org/x deps to clear CVEs ([25ce4fb](https://github.com/OctopusDeploy/cli/commit/25ce4fbe3fe9e9526546d06acd716a68d52ce519)), closes [#583](https://github.com/OctopusDeploy/cli/issues/583)

## [2.21.4](https://github.com/OctopusDeploy/cli/compare/v2.21.3...v2.21.4) (2026-07-16)


### Bug Fixes

* allow completion command to run without an Octopus login ([#612](https://github.com/OctopusDeploy/cli/issues/612)) ([a3fe8a9](https://github.com/OctopusDeploy/cli/commit/a3fe8a98e80792c216bdd4644f91be24ad42070e))

## [2.21.3](https://github.com/OctopusDeploy/cli/compare/v2.21.2...v2.21.3) (2026-05-26)


### Bug Fixes

* Include Default Worker Pool for Azure Web App targets ([#603](https://github.com/OctopusDeploy/cli/issues/603)) ([6502516](https://github.com/OctopusDeploy/cli/commit/65025165bcf9451cd5f06e856d1996c8e575f345)), closes [#600](https://github.com/OctopusDeploy/cli/issues/600)

## [2.21.1](https://github.com/OctopusDeploy/cli/compare/v2.21.0...v2.21.1) (2026-05-13)


### Bug Fixes

* set default worker pool correctly on azure web app target create ([#596](https://github.com/OctopusDeploy/cli/issues/596)) ([fc2df3d](https://github.com/OctopusDeploy/cli/commit/fc2df3d42acfd74340d18cae2f2d77976c00d07b)), closes [#595](https://github.com/OctopusDeploy/cli/issues/595)

## [2.21.0](https://github.com/OctopusDeploy/cli/compare/v2.20.1...v2.21.0) (2026-04-08)


### Features

* Add --runbook-tag flag to run multiple runbooks by tag ([#576](https://github.com/OctopusDeploy/cli/issues/576)) ([7eb348a](https://github.com/OctopusDeploy/cli/commit/7eb348a5643095f3f7b78f24217f06c2a2e0fa54))
* Add support for target tag sets with --tag flag ([#579](https://github.com/OctopusDeploy/cli/issues/579)) ([f2871d1](https://github.com/OctopusDeploy/cli/commit/f2871d1aa4b4fe001aa47a9da0cf5c3821897ed6))
* added api command to support a GET request against any octopus api endpoint ([#586](https://github.com/OctopusDeploy/cli/issues/586)) ([8938780](https://github.com/OctopusDeploy/cli/commit/89387809d6f8e3e8f279a4506053165d27134d9c))
* service message flag support ([#574](https://github.com/OctopusDeploy/cli/issues/574)) ([e1ccf99](https://github.com/OctopusDeploy/cli/commit/e1ccf99c7fcfc0f02b9c583e9e3545e66956bc70))
* Support custom AWS region for accounts ([#581](https://github.com/OctopusDeploy/cli/issues/581)) ([a22dd0f](https://github.com/OctopusDeploy/cli/commit/a22dd0fb1aa1dee9c98047109b9be486667969da))


### Bug Fixes

* extended automation command to include Space ([#587](https://github.com/OctopusDeploy/cli/issues/587)) ([9c835d1](https://github.com/OctopusDeploy/cli/commit/9c835d1f6cf2e297314d624467063d1e4035731a))

## [2.20.1](https://github.com/OctopusDeploy/cli/compare/v2.20.0...v2.20.1) (2025-12-04)


### Bug Fixes

* Update go version to 1.25.5 ([#570](https://github.com/OctopusDeploy/cli/issues/570)) ([30e12e9](https://github.com/OctopusDeploy/cli/commit/30e12e9342f4388f887a0535b8e63c55d8fe6ae1))

## [2.20.0](https://github.com/OctopusDeploy/cli/compare/v2.19.1...v2.20.0) (2025-12-01)


### Features

* Add ephemeral environment create command ([#559](https://github.com/OctopusDeploy/cli/issues/559)) ([0fc0cdd](https://github.com/OctopusDeploy/cli/commit/0fc0cddda3f30343a1f6f72d4bf3429d7e729a48))
* Add support to deprovision environment ([#562](https://github.com/OctopusDeploy/cli/issues/562)) ([8d430ef](https://github.com/OctopusDeploy/cli/commit/8d430eff2abf280fe5c53036932e8c3d74df26c3))
* Add support to view/add/update project tags ([#567](https://github.com/OctopusDeploy/cli/issues/567)) ([2e2340a](https://github.com/OctopusDeploy/cli/commit/2e2340ab1494e1846bdf454e094aa5392243ee8e))
* Extend tag sets and add environment tags ([#548](https://github.com/OctopusDeploy/cli/issues/548)) ([4dbefbd](https://github.com/OctopusDeploy/cli/commit/4dbefbd3059c1d023c0441855ca64f6f57497b6b))


### Bug Fixes

* Bump go version ([f5b6927](https://github.com/OctopusDeploy/cli/commit/f5b692704de454cbce3fc3df2345d3c18ad7f6ba))

## [2.19.1](https://github.com/OctopusDeploy/cli/compare/v2.19.0...v2.19.1) (2025-10-09)


### Bug Fixes

* Update go version to patch CVE-2025-22871 ([29f0d26](https://github.com/OctopusDeploy/cli/commit/29f0d2668ba46b727d88a265bd01d416d7784d1a))

## [2.19.0](https://github.com/OctopusDeploy/cli/compare/v2.18.0...v2.19.0) (2025-09-25)


### Features

* `octopus deployment-target view` support -f parameter ([#538](https://github.com/OctopusDeploy/cli/issues/538)) ([2cd8853](https://github.com/OctopusDeploy/cli/commit/2cd885344360596e86d6e9e6b5b359fabeb0f819))
* `worker view` and `work-pool view` support -f parameter ([#537](https://github.com/OctopusDeploy/cli/issues/537)) ([4446ba6](https://github.com/OctopusDeploy/cli/commit/4446ba644a7aadfe3fc62860be74156aa4db3a35))
* add oidc account support for azure web app deployment target ([#534](https://github.com/OctopusDeploy/cli/issues/534)) ([6254eb8](https://github.com/OctopusDeploy/cli/commit/6254eb88cbbd7dc1aff646ede9a52c82b894a8dd))
* Add support for setting custom fields on releases ([#545](https://github.com/OctopusDeploy/cli/issues/545)) ([4aac03a](https://github.com/OctopusDeploy/cli/commit/4aac03a3bb3254bf7f05ebb5b0923091c3fcbfde))
* project-group view command support -f options ([#536](https://github.com/OctopusDeploy/cli/issues/536)) ([dcce548](https://github.com/OctopusDeploy/cli/commit/dcce548ec9c70f0253ff3e529d665b934c109663))
* Space view command support -f param ([#531](https://github.com/OctopusDeploy/cli/issues/531)) ([3408f2d](https://github.com/OctopusDeploy/cli/commit/3408f2d7f13bb9b15d522ad85c9c0b20fa4f6768))
* support project view -f for project view ([#533](https://github.com/OctopusDeploy/cli/issues/533)) ([e6a5343](https://github.com/OctopusDeploy/cli/commit/e6a53430e2f5fee1d0bb1c715a28330e811f9f5e))
* task wait command support -f argument ([#535](https://github.com/OctopusDeploy/cli/issues/535)) ([5ac6e6d](https://github.com/OctopusDeploy/cli/commit/5ac6e6d03e3a7070aa9908dbba2dbeedca7cbba2))


### Bug Fixes

* default output to table as global config ([#539](https://github.com/OctopusDeploy/cli/issues/539)) ([2fb738a](https://github.com/OctopusDeploy/cli/commit/2fb738ac809be1229a54e1598570ab477e51b42f))
* issue release id missing in json output ([#540](https://github.com/OctopusDeploy/cli/issues/540)) ([74a0f79](https://github.com/OctopusDeploy/cli/commit/74a0f79b6e72360666d78dcded1ceef987fc9434))

## [2.18.0](https://github.com/OctopusDeploy/cli/compare/v2.17.0...v2.18.0) (2025-05-28)


### Features

* warn about missing packages when deploying ([b5b93ff](https://github.com/OctopusDeploy/cli/commit/b5b93ff8c540108ce860d56d7c88b2161851dad6))

## [2.17.0](https://github.com/OctopusDeploy/cli/compare/v2.16.0...v2.17.0) (2025-05-15)


### Features

* add option to cancel task on wait timeout  ([84b1bac](https://github.com/OctopusDeploy/cli/commit/84b1bac5ba3d5aa4ba97c012b92ab062ca5db97f))

## [2.16.0](https://github.com/OctopusDeploy/cli/compare/v2.15.7...v2.16.0) (2025-05-02)


### Features

* runbook snapshot create ([#514](https://github.com/OctopusDeploy/cli/issues/514)) ([d7b7330](https://github.com/OctopusDeploy/cli/commit/d7b7330e1f241e7d8468154fb19b7817b1ea767c))
* runbook snapshot publish ([d7b7330](https://github.com/OctopusDeploy/cli/commit/d7b7330e1f241e7d8468154fb19b7817b1ea767c))
* show the published runbook snapshot when listing ([d7b7330](https://github.com/OctopusDeploy/cli/commit/d7b7330e1f241e7d8468154fb19b7817b1ea767c))

## [2.15.7](https://github.com/OctopusDeploy/cli/compare/v2.15.6...v2.15.7) (2025-04-14)


### Bug Fixes

* Add missing title property to nuspec ([#511](https://github.com/OctopusDeploy/cli/issues/511)) ([3c0f97c](https://github.com/OctopusDeploy/cli/commit/3c0f97ce244a248e89212e988f9ee1a37f1acc3d))

## [2.15.6](https://github.com/OctopusDeploy/cli/compare/v2.15.5...v2.15.6) (2025-03-13)


### Features

* Add deployment freeze override flags [#463](https://github.com/OctopusDeploy/cli/issues/463) ([0dc7bfd](https://github.com/OctopusDeploy/cli/commit/0dc7bfd0915e5a71acc5e3e8e335b4c04f127bc2))

## [2.15.5](https://github.com/OctopusDeploy/cli/compare/v2.15.4...v2.15.5) (2025-03-07)


### Bug Fixes

* Fix deleting variables from other variable sets [#502](https://github.com/OctopusDeploy/cli/issues/502) ([788a9a3](https://github.com/OctopusDeploy/cli/commit/788a9a3ae4fd9ceb186d6c0f4290ac058391b926))

## [2.15.4](https://github.com/OctopusDeploy/cli/compare/v2.15.3...v2.15.4) (2025-03-07)


### Features

* Enable updates of scoped common variables [#489](https://github.com/OctopusDeploy/cli/issues/489) ([361054c](https://github.com/OctopusDeploy/cli/commit/361054c0b22349bdb5e36d1439e1de54358d813c))

## [2.15.3](https://github.com/OctopusDeploy/cli/compare/v2.15.2...v2.15.3) (2025-03-05)


### Bug Fixes

* Pump go-octopusdeploy to fix vulnerabilities-package ([#498](https://github.com/OctopusDeploy/cli/issues/498)) ([0983510](https://github.com/OctopusDeploy/cli/commit/09835103ce2bc5b9a7506c68f82517a76108582e))

## [2.15.2](https://github.com/OctopusDeploy/cli/compare/v2.15.1...v2.15.2) (2025-03-04)


### Miscellaneous Chores

* **main:** release 2.15.2 ([3c90363](https://github.com/OctopusDeploy/cli/commit/3c90363e77cd55298cd4d6a21b8897768d4af741))

## [2.15.0](https://github.com/OctopusDeploy/cli/compare/v2.14.3...v2.15.0) (2025-02-14)


### Features

* Task wait support --progress flag to print task logs and some enhancement ([8eaf696](https://github.com/OctopusDeploy/cli/commit/8eaf6966c5699b2effd3a18a349c065fc61022d4))

## [2.14.3](https://github.com/OctopusDeploy/cli/compare/v2.14.2...v2.14.3) (2025-02-11)


### Bug Fixes

* Check runbook variable context when prompt variable ([#480](https://github.com/OctopusDeploy/cli/issues/480)) ([13337bf](https://github.com/OctopusDeploy/cli/commit/13337bf0e02694acf667d211cd8853f663d9844d))

## [2.14.2](https://github.com/OctopusDeploy/cli/compare/v2.14.1...v2.14.2) (2025-01-24)


### Bug Fixes

* issue verbose output of the octopus package nuget create ([#474](https://github.com/OctopusDeploy/cli/issues/474)) ([68ceb24](https://github.com/OctopusDeploy/cli/commit/68ceb247c5d7013240f299d0cafc07fef80a99fc))
* Use first option as default selection if don't specific by variable and add test case cover that scenario ([9e96ae5](https://github.com/OctopusDeploy/cli/commit/9e96ae5c64ff75027d1881d7f6c89fd5509c85b0))

## [2.14.1](https://github.com/OctopusDeploy/cli/compare/v2.14.0...v2.14.1) (2025-01-23)


### Bug Fixes

* Use first option as default selection if dont sepecific by variable ([4932b5d](https://github.com/OctopusDeploy/cli/commit/4932b5d0a8edc7220ea187a9f9b20c9bf8b3bf68))

## [2.14.0](https://github.com/OctopusDeploy/cli/compare/v2.13.0...v2.14.0) (2024-12-04)


### Features

* Add support for generic oidc accounts ([#455](https://github.com/OctopusDeploy/cli/issues/455)) ([87745a9](https://github.com/OctopusDeploy/cli/commit/87745a9aa4ae5046ed848bd89a3f64e7d922ddf2))

## [2.13.0](https://github.com/OctopusDeploy/cli/compare/v2.12.2...v2.13.0) (2024-12-02)


### Features

* Add support for deleting Git runbooks ([#444](https://github.com/OctopusDeploy/cli/issues/444)) ([64915bc](https://github.com/OctopusDeploy/cli/commit/64915bcc87328e469cd73958aa4c0b191f2854cc))
* Add support for listing Git runbooks ([#443](https://github.com/OctopusDeploy/cli/issues/443)) ([e5d1966](https://github.com/OctopusDeploy/cli/commit/e5d1966c350af0dbfb10ded7b96378b7445ae93d))
* Add support for running Git runbooks ([#441](https://github.com/OctopusDeploy/cli/issues/441)) ([7cc29ad](https://github.com/OctopusDeploy/cli/commit/7cc29ad4afe2a511560947bac39bd9ad8b1a5cb3))
* Adds an option to disable ssl verifications for login for use of custom certs ([22d93bd](https://github.com/OctopusDeploy/cli/commit/22d93bd33dba3bc15704e8bba904a7110f5a2116))

## [2.12.2](https://github.com/OctopusDeploy/cli/compare/v2.12.1...v2.12.2) (2024-11-20)


### Bug Fixes

* incorrect disable tenant example ([#451](https://github.com/OctopusDeploy/cli/issues/451)) ([d5393e3](https://github.com/OctopusDeploy/cli/commit/d5393e3015a082ac438f2b28092db86bf936a279))

## [2.12.1](https://github.com/OctopusDeploy/cli/compare/v2.12.0...v2.12.1) (2024-11-20)


### Bug Fixes

* disable/enable tenant command docs ([#448](https://github.com/OctopusDeploy/cli/issues/448)) ([c5222b5](https://github.com/OctopusDeploy/cli/commit/c5222b5bc1175407a62992958e571a58e7247fba))

## [2.12.0](https://github.com/OctopusDeploy/cli/compare/v2.11.0...v2.12.0) (2024-11-20)


### Features

* add ability to disable tenants ([#445](https://github.com/OctopusDeploy/cli/issues/445)) ([44063aa](https://github.com/OctopusDeploy/cli/commit/44063aae00fa770ea320014e375f657c884f4327))

## [2.11.0](https://github.com/OctopusDeploy/cli/compare/v2.10.4...v2.11.0) (2024-10-30)


### Features

* Add support for fixed package versions in release creation ([#435](https://github.com/OctopusDeploy/cli/issues/435)) ([8559b9a](https://github.com/OctopusDeploy/cli/commit/8559b9a6dbff9ae37aefda99e7d342671f4d0a16))

## [2.10.3](https://github.com/OctopusDeploy/cli/compare/v2.10.2...v2.10.3) (2024-10-11)


### Bug Fixes

* correct help text in tenant variable commands ([#430](https://github.com/OctopusDeploy/cli/issues/430)) ([e414d7f](https://github.com/OctopusDeploy/cli/commit/e414d7f06d3376125aa59c1f33e118326487a20d))

## [2.10.2](https://github.com/OctopusDeploy/cli/compare/v2.10.1...v2.10.2) (2024-09-20)


### Bug Fixes

* handle non-nil fields in task wait ([#422](https://github.com/OctopusDeploy/cli/issues/422)) ([6d20dd9](https://github.com/OctopusDeploy/cli/commit/6d20dd98a90d6c53d8ce8dffa284ba2fbc191816))

## [2.10.1](https://github.com/OctopusDeploy/cli/compare/v2.10.0...v2.10.1) (2024-09-19)


### Bug Fixes

* include release notes and assembled date in json output after creating a release ([#410](https://github.com/OctopusDeploy/cli/issues/410)) ([42f2db6](https://github.com/OctopusDeploy/cli/commit/42f2db66e93846aebb53056b59751c0c9a938451))

## [2.10.0](https://github.com/OctopusDeploy/cli/compare/v2.9.1...v2.10.0) (2024-09-18)


### Features

* handle failures in task wait ([#393](https://github.com/OctopusDeploy/cli/issues/393)) ([da8a86b](https://github.com/OctopusDeploy/cli/commit/da8a86bcc58e56f59a211e2cc26a849e373d635e))

## [2.9.1](https://github.com/OctopusDeploy/cli/compare/v2.9.0...v2.9.1) (2024-09-18)


### Bug Fixes

* Removes a whitespace between Path key and value when creating a zip/nupkg with json output format ([59de77a](https://github.com/OctopusDeploy/cli/commit/59de77a3aaf027fc9228d93315097c428245bae8))

## [2.9.0](https://github.com/OctopusDeploy/cli/compare/v2.8.1...v2.9.0) (2024-09-17)


### Features

* print packages that get created ([#404](https://github.com/OctopusDeploy/cli/issues/404)) ([f648633](https://github.com/OctopusDeploy/cli/commit/f648633fa0a2e5f9e77244c3e66c4f17d46c5aba))

## [2.8.1](https://github.com/OctopusDeploy/cli/compare/v2.8.0...v2.8.1) (2024-09-16)


### Bug Fixes

* no program args now outputs the root help again ([#398](https://github.com/OctopusDeploy/cli/issues/398)) ([a0eec58](https://github.com/OctopusDeploy/cli/commit/a0eec582999df9aeaa17fcd4a9ddbf958d940c13))

## [2.8.0](https://github.com/OctopusDeploy/cli/compare/v2.7.0...v2.8.0) (2024-09-16)


### Features

* add ability to change git refs when creating release ([#392](https://github.com/OctopusDeploy/cli/issues/392)) ([5409353](https://github.com/OctopusDeploy/cli/commit/540935358adcdace7b53165d473ec38c762611e2))

## [2.7.0](https://github.com/OctopusDeploy/cli/compare/v2.6.0...v2.7.0) (2024-07-30)


### Features

* add commands to manage release progression ([#382](https://github.com/OctopusDeploy/cli/issues/382)) ([ccb6df6](https://github.com/OctopusDeploy/cli/commit/ccb6df63f5b8b460008ef623e3a46d6c306d6b35))

## [2.6.0](https://github.com/OctopusDeploy/cli/compare/v2.5.0...v2.6.0) (2024-07-15)


### Features

* add create channel command ([#377](https://github.com/OctopusDeploy/cli/issues/377)) ([a35a111](https://github.com/OctopusDeploy/cli/commit/a35a111218030e81b0504f9cb887a4a5c9f9428b))
* add delete package command ([#374](https://github.com/OctopusDeploy/cli/issues/374)) ([b47061d](https://github.com/OctopusDeploy/cli/commit/b47061d26bb94319f889315bea130602cb441e38))
* add disable project command ([#370](https://github.com/OctopusDeploy/cli/issues/370)) ([b91b062](https://github.com/OctopusDeploy/cli/commit/b91b06291cfaa7b080a7a9b26843c0f3c239a1d9))
* add enable project command ([#372](https://github.com/OctopusDeploy/cli/issues/372)) ([e29c5b4](https://github.com/OctopusDeploy/cli/commit/e29c5b4f1451037b4a00a3df6b61c22f03e2416d))


### Bug Fixes

* fix command use value as it was capitalised ([#375](https://github.com/OctopusDeploy/cli/issues/375)) ([6f20227](https://github.com/OctopusDeploy/cli/commit/6f20227a79d8b2ffd808bf65c71d0584686fec3c))

## [2.5.0](https://github.com/OctopusDeploy/cli/compare/v2.4.0...v2.5.0) (2024-07-11)


### Features

* add bulk delete build information command ([#369](https://github.com/OctopusDeploy/cli/issues/369)) ([c1631da](https://github.com/OctopusDeploy/cli/commit/c1631da60d8a224e068fda8904f186c940b36f33))
* add delete build information command ([#368](https://github.com/OctopusDeploy/cli/issues/368)) ([8e66095](https://github.com/OctopusDeploy/cli/commit/8e660954673b3fe8991abfe9082520de1b4b1857))
* add list build information command ([#366](https://github.com/OctopusDeploy/cli/issues/366)) ([0a17e9f](https://github.com/OctopusDeploy/cli/commit/0a17e9f6b04fc36ad9a297db4959c951053a201c))
* add upload build info command ([#364](https://github.com/OctopusDeploy/cli/issues/364)) ([189beb4](https://github.com/OctopusDeploy/cli/commit/189beb474c7a01d3d539a51bd13d998d9520022e))
* add view build information command ([#367](https://github.com/OctopusDeploy/cli/issues/367)) ([e56c4cc](https://github.com/OctopusDeploy/cli/commit/e56c4ccad63e4edab598a4a9b416e451cfa69819))

## [2.4.0](https://github.com/OctopusDeploy/cli/compare/v2.3.1...v2.4.0) (2024-06-30)


### Features

* add support for delta package uploads using go-octodiff ([#226](https://github.com/OctopusDeploy/cli/issues/226)) ([a0650c1](https://github.com/OctopusDeploy/cli/commit/a0650c1dbd2222b0ab8ae9b9234a3cc307528f4b))

## [2.3.1](https://github.com/OctopusDeploy/cli/compare/v2.3.0...v2.3.1) (2024-06-26)


### Bug Fixes

* Add ability to escape special character when parsing variables argument ([377ddb2](https://github.com/OctopusDeploy/cli/commit/377ddb2102747914be362a496d63876e3a442c4f))

## [2.3.0](https://github.com/OctopusDeploy/cli/compare/v2.2.1...v2.3.0) (2024-05-31)


### Features

* environment create ([#338](https://github.com/OctopusDeploy/cli/issues/338)) ([88d0588](https://github.com/OctopusDeploy/cli/commit/88d058876b63def96ae80a2db2893b43d8546f3c))
* runbook delete ([#341](https://github.com/OctopusDeploy/cli/issues/341)) ([2bbb1ff](https://github.com/OctopusDeploy/cli/commit/2bbb1ff6b94f77294f8b8b6eb432c326c67acb93))
* runbook snapshot list ([#340](https://github.com/OctopusDeploy/cli/issues/340)) ([43d5f2c](https://github.com/OctopusDeploy/cli/commit/43d5f2cae0fae861c49c8403f81f888f0a990e12))


### Bug Fixes

* wrong url for new infrastucture ([#351](https://github.com/OctopusDeploy/cli/issues/351)) ([67f9c14](https://github.com/OctopusDeploy/cli/commit/67f9c148c86efa0691805b8a4fa22b29bb66110f))

## [2.2.1](https://github.com/OctopusDeploy/cli/compare/v2.2.0...v2.2.1) (2024-03-07)


### Bug Fixes

* panic when no arguments and no config ([#336](https://github.com/OctopusDeploy/cli/issues/336)) ([44b3e0f](https://github.com/OctopusDeploy/cli/commit/44b3e0fa6cea934e3e88d0717437a618bf7f3f4b))

## [2.2.0](https://github.com/OctopusDeploy/cli/compare/v2.1.1...v2.2.0) (2024-02-23)


### Features

* **tenant:** Tenant view command support for output formatting ([#331](https://github.com/OctopusDeploy/cli/issues/331)) ([0112f1b](https://github.com/OctopusDeploy/cli/commit/0112f1b500096b364c6aeb601b1e2260c4b1474e))


### Bug Fixes

* support virtual paths during login ([#334](https://github.com/OctopusDeploy/cli/issues/334)) ([60e43f4](https://github.com/OctopusDeploy/cli/commit/60e43f4527f9cd82dccef94d6aa02f45fbc34c32))

## [2.1.1](https://github.com/OctopusDeploy/cli/compare/v2.1.0...v2.1.1) (2024-02-12)


### Bug Fixes

* remove requirement for server config on package create commands ([#323](https://github.com/OctopusDeploy/cli/issues/323)) ([f755841](https://github.com/OctopusDeploy/cli/commit/f75584156b04bec28d41def60360e5953acce0a6))

## [2.1.0](https://github.com/OctopusDeploy/cli/compare/v2.0.0...v2.1.0) (2024-01-08)


### Features

* Add new login and logout commands ([#291](https://github.com/OctopusDeploy/cli/issues/291)) ([7d4da60](https://github.com/OctopusDeploy/cli/commit/7d4da6049c8163a67ea118e3eee7c0d25028efe0))

## [2.0.0](https://github.com/OctopusDeploy/cli/compare/v1.7.1...v2.0.0) (2024-01-04)


### ⚠ BREAKING CHANGES

* bug where lists weren't parsing correctly when names contain a comma ([#306](https://github.com/OctopusDeploy/cli/issues/306))

### Features

* account azure-oidc create ([#296](https://github.com/OctopusDeploy/cli/issues/296)) ([554d171](https://github.com/OctopusDeploy/cli/commit/554d17154c980caae90f52f047696321dd6dd6d3))


### Bug Fixes

* bug where lists weren't parsing correctly when names contain a comma ([#306](https://github.com/OctopusDeploy/cli/issues/306)) ([09e1cc3](https://github.com/OctopusDeploy/cli/commit/09e1cc3093cacefc22c8c15631e2b011d9eaaec9))

## [1.7.1](https://github.com/OctopusDeploy/cli/compare/v1.7.0...v1.7.1) (2023-10-31)


### Bug Fixes

* Add additional fields to json output when listing workers ([#287](https://github.com/OctopusDeploy/cli/issues/287)) ([dc2b5c6](https://github.com/OctopusDeploy/cli/commit/dc2b5c659cf479a7e534ab267730b47f08301076))

## [1.7.0](https://github.com/OctopusDeploy/cli/compare/v1.6.2...v1.7.0) (2023-10-31)


### Features

* Update fields included in JSON output for workers list ([#284](https://github.com/OctopusDeploy/cli/issues/284)) ([9bb3d43](https://github.com/OctopusDeploy/cli/commit/9bb3d43ba9eddf39d73887bb021683b953f15776))

## [1.6.2](https://github.com/OctopusDeploy/cli/compare/v1.6.1...v1.6.2) (2023-09-14)


### Bug Fixes

* octopus deploy process for homebrew ([3c82836](https://github.com/OctopusDeploy/cli/commit/3c828368cee0b01844d46eaa6076469825f73e53))

## [1.6.1](https://github.com/OctopusDeploy/cli/compare/v1.6.0...v1.6.1) (2023-09-14)


### Bug Fixes

* homebrew deployments ([#273](https://github.com/OctopusDeploy/cli/issues/273)) ([4d3845a](https://github.com/OctopusDeploy/cli/commit/4d3845ad5bbc1529f77161d028ce4537626c5053))

## [1.6.0](https://github.com/OctopusDeploy/cli/compare/v1.5.1...v1.6.0) (2023-09-08)


### Features

* Adds support for authenticating with access token ([#270](https://github.com/OctopusDeploy/cli/issues/270)) ([75a8ff7](https://github.com/OctopusDeploy/cli/commit/75a8ff7b622f6ed9a353c83a4d3afa7dc0f93b9f))

## [1.5.1](https://github.com/OctopusDeploy/cli/compare/v1.5.0...v1.5.1) (2023-08-10)


### Bug Fixes

* prompt checks for git credentials storage was case-sensitive ([#265](https://github.com/OctopusDeploy/cli/issues/265)) ([c9a5817](https://github.com/OctopusDeploy/cli/commit/c9a5817dfb8e0875a0b70e0ae6243f5012eaedef))

## [1.5.0](https://github.com/OctopusDeploy/cli/compare/v1.4.0...v1.5.0) (2023-07-25)


### Features

* project branch create ([101b09e](https://github.com/OctopusDeploy/cli/commit/101b09e409c2885beb19ae9e66b88a977f0c985b))
* project branch list ([101b09e](https://github.com/OctopusDeploy/cli/commit/101b09e409c2885beb19ae9e66b88a977f0c985b))


### Bug Fixes

* admin login property on k8s target was wrong type ([#249](https://github.com/OctopusDeploy/cli/issues/249)) ([fbe8e18](https://github.com/OctopusDeploy/cli/commit/fbe8e18d041cf416fc0013451f416363eb0a83e5))
* support Config-as-code project variables ([101b09e](https://github.com/OctopusDeploy/cli/commit/101b09e409c2885beb19ae9e66b88a977f0c985b))

## [1.4.0](https://github.com/OctopusDeploy/cli/compare/v1.3.0...v1.4.0) (2023-06-08)


### Features

* project clone ([#244](https://github.com/OctopusDeploy/cli/issues/244)) ([f6a0ba5](https://github.com/OctopusDeploy/cli/commit/f6a0ba5d7a1f55f78ea6c6eb2fb8ecfa38bf1c4a))


### Bug Fixes

* sort the possible variables before displaying ([#240](https://github.com/OctopusDeploy/cli/issues/240)) ([61f5073](https://github.com/OctopusDeploy/cli/commit/61f5073d0d2b247ceddfc10902072357fdb0d685))

## [1.3.0](https://github.com/OctopusDeploy/cli/compare/v1.2.2...v1.3.0) (2023-05-23)


### Features

* tenant variable list ([69bb317](https://github.com/OctopusDeploy/cli/commit/69bb3177441b7d4d9e2928e564a61e36343e0a7c))
* tenant variable update ([69bb317](https://github.com/OctopusDeploy/cli/commit/69bb3177441b7d4d9e2928e564a61e36343e0a7c))

## [1.2.2](https://github.com/OctopusDeploy/cli/compare/v1.2.1...v1.2.2) (2023-05-21)


### Bug Fixes

* fixed incorrect example ([#234](https://github.com/OctopusDeploy/cli/issues/234)) ([969ef1b](https://github.com/OctopusDeploy/cli/commit/969ef1b17cad755c8f7a5087c358e97cac8bad86))

## [1.2.1](https://github.com/OctopusDeploy/cli/compare/v1.2.0...v1.2.1) (2023-05-12)


### Bug Fixes

* added support for project slugs to release commands ([#230](https://github.com/OctopusDeploy/cli/issues/230)) ([851631a](https://github.com/OctopusDeploy/cli/commit/851631a0086549fc12528b72f48be9952d5a84af))

## [1.2.0](https://github.com/OctopusDeploy/cli/compare/v1.1.0...v1.2.0) (2023-01-31)


### Features

* project variables exclude ([9e0c0b8](https://github.com/OctopusDeploy/cli/commit/9e0c0b8584b80c5bfa87915b39c5991ebe61ff51))
* project variables include ([9e0c0b8](https://github.com/OctopusDeploy/cli/commit/9e0c0b8584b80c5bfa87915b39c5991ebe61ff51))

## [1.1.0](https://github.com/OctopusDeploy/cli/compare/v1.0.0...v1.1.0) (2023-01-25)


### Features

* project variables create ([#198](https://github.com/OctopusDeploy/cli/issues/198)) ([faa3b4c](https://github.com/OctopusDeploy/cli/commit/faa3b4c46dad0167859d3e053dec9229832b9159))
* project variables delete ([faa3b4c](https://github.com/OctopusDeploy/cli/commit/faa3b4c46dad0167859d3e053dec9229832b9159))
* project variables list ([faa3b4c](https://github.com/OctopusDeploy/cli/commit/faa3b4c46dad0167859d3e053dec9229832b9159))
* project variables update ([faa3b4c](https://github.com/OctopusDeploy/cli/commit/faa3b4c46dad0167859d3e053dec9229832b9159))
* project variables view ([faa3b4c](https://github.com/OctopusDeploy/cli/commit/faa3b4c46dad0167859d3e053dec9229832b9159))


### Bug Fixes

* empty list errors ([#208](https://github.com/OctopusDeploy/cli/issues/208)) ([74cbfe2](https://github.com/OctopusDeploy/cli/commit/74cbfe2c98c2ce26153fe4c8521b0292c076acb7))
* link convert options to create when in non-interactive mode ([#213](https://github.com/OctopusDeploy/cli/issues/213)) ([adccfd9](https://github.com/OctopusDeploy/cli/commit/adccfd9f19ae8be0332f05d067f536f89cef4e91))

## [1.0.0](https://github.com/OctopusDeploy/cli/compare/v0.10.2...v1.0.0) (2023-01-05)


### ⚠ BREAKING CHANGES

* package

### Features

* package ([088df06](https://github.com/OctopusDeploy/cli/commit/088df0673c2bf88928f2f5ce86dff46533cb0dd7))


### Bug Fixes

* null ref exception in  `account create` command ([#204](https://github.com/OctopusDeploy/cli/issues/204)) ([204f706](https://github.com/OctopusDeploy/cli/commit/204f706b48bb606fa52e7ef5223845775d344ec6))
* remove project convert support for default protected branch  ([#199](https://github.com/OctopusDeploy/cli/issues/199)) ([05ee50a](https://github.com/OctopusDeploy/cli/commit/05ee50a9d8a7e04ea7afbf1858c3f2d5bfd909a1))

## [0.10.2](https://github.com/OctopusDeploy/cli/compare/v0.10.1...v0.10.2) (2022-12-23)


### Bug Fixes

* Fixed go releaser setup to fix release notes ([#196](https://github.com/OctopusDeploy/cli/issues/196)) ([7d5f720](https://github.com/OctopusDeploy/cli/commit/7d5f72020317286479d2557a00bb5e8d56db06b8))

## [0.10.1](https://github.com/OctopusDeploy/cli/compare/v0.10.0...v0.10.1) (2022-12-23)


### Bug Fixes

* Fixes for Go Releaser, moving it to Ocotpus' v3 GitHub Actions ([#194](https://github.com/OctopusDeploy/cli/issues/194)) ([77f023b](https://github.com/OctopusDeploy/cli/commit/77f023b31f0c4b50f6d213b97a7ff3f3eea364dc))

## [0.10.0](https://github.com/OctopusDeploy/cli/compare/v0.9.0...v0.10.0) (2022-12-23)


### Features

* Fixed the OCTOPUS_URL environment variable name ([#191](https://github.com/OctopusDeploy/cli/issues/191)) ([1aa1a98](https://github.com/OctopusDeploy/cli/commit/1aa1a98170b82fb536d67541d913fb825f9c075f))


### Bug Fixes

* typo in workerpool message ([#193](https://github.com/OctopusDeploy/cli/issues/193)) ([baf2a46](https://github.com/OctopusDeploy/cli/commit/baf2a46d70582b101f952703ed3605e4210dc3a6))

## [0.9.0](https://github.com/OctopusDeploy/cli/compare/v0.8.1...v0.9.0) (2022-12-21)


### Features

* clone tenant ([#184](https://github.com/OctopusDeploy/cli/issues/184)) ([9bc3b6d](https://github.com/OctopusDeploy/cli/commit/9bc3b6d702f69b9c2359d3cf65ade0fa241c0689))

## [0.8.1](https://github.com/OctopusDeploy/cli/compare/v0.8.0...v0.8.1) (2022-12-19)


### Bug Fixes

* updated dependencies ([d009065](https://github.com/OctopusDeploy/cli/commit/d009065b22f48d922f02126e6cf908fe8372bd40))

## [0.8.0](https://github.com/OctopusDeploy/cli/compare/v0.7.1...v0.8.0) (2022-12-19)


### Features

* kubernetes deployment target ([#178](https://github.com/OctopusDeploy/cli/issues/178)) ([6e25759](https://github.com/OctopusDeploy/cli/commit/6e257593b4f08c354249a9faa4ba9549c2136787))

## [0.7.1](https://github.com/OctopusDeploy/cli/compare/v0.7.0...v0.7.1) (2022-12-16)


### Bug Fixes

* expand tenant view output ([#174](https://github.com/OctopusDeploy/cli/issues/174)) ([7e3efce](https://github.com/OctopusDeploy/cli/commit/7e3efce9f7bc5acf8a24a906404b3c7b32209c58))
* extended release output ([#179](https://github.com/OctopusDeploy/cli/issues/179)) ([80e1200](https://github.com/OctopusDeploy/cli/commit/80e120078c807baa451b887a6e736acdbfe20dce))

## [0.7.0](https://github.com/OctopusDeploy/cli/compare/v0.6.0...v0.7.0) (2022-12-13)


### Features

* `worker-pool dynamic view` ([b2cd68c](https://github.com/OctopusDeploy/cli/commit/b2cd68cae80cc913875674c0dbc84dd9ec54c84b))
* `worker-pool static view` ([b2cd68c](https://github.com/OctopusDeploy/cli/commit/b2cd68cae80cc913875674c0dbc84dd9ec54c84b))
* basic `user list` and `user delete` ([74fdc7e](https://github.com/OctopusDeploy/cli/commit/74fdc7e0a811dcc6444d2fd48df3cbb661e87503))
* convert existing project to Config As Code ([2788964](https://github.com/OctopusDeploy/cli/commit/2788964e8f5aa799d16b6259118adec7f4228f7a))
* worker-pool delete ([#161](https://github.com/OctopusDeploy/cli/issues/161)) ([bb11b10](https://github.com/OctopusDeploy/cli/commit/bb11b105fea2d6253c67077e51a2a2657be6afd7))
* worker-pool list ([#158](https://github.com/OctopusDeploy/cli/issues/158)) ([b2cd68c](https://github.com/OctopusDeploy/cli/commit/b2cd68cae80cc913875674c0dbc84dd9ec54c84b))
* workerpool static create ([#162](https://github.com/OctopusDeploy/cli/issues/162)) ([3f3b66c](https://github.com/OctopusDeploy/cli/commit/3f3b66cf8ca59e5707ab85f5dddbd4b171a00f70))


### Bug Fixes

* skip prompt if only a single channel ([#172](https://github.com/OctopusDeploy/cli/issues/172)) ([01e3cbb](https://github.com/OctopusDeploy/cli/commit/01e3cbb7f1b15eafe5793e5bd2920d31774b4537))
* validate environments for tenanted deployments ([#168](https://github.com/OctopusDeploy/cli/issues/168)) ([c4f7cb9](https://github.com/OctopusDeploy/cli/commit/c4f7cb904723ee198549eb21e62c93575514e215))
* version shortcut on release create ([#171](https://github.com/OctopusDeploy/cli/issues/171)) ([9183324](https://github.com/OctopusDeploy/cli/commit/918332406f2efed3014edbdad64f60727e04d704))

## [0.6.0](https://github.com/OctopusDeploy/cli/compare/v0.5.0...v0.6.0) (2022-11-23)


### Features

* create azure web app target ([20d66b3](https://github.com/OctopusDeploy/cli/commit/20d66b32518685d49aff1ec9558c39d370ab4831))
* create cloud region deployment target ([#137](https://github.com/OctopusDeploy/cli/issues/137)) ([672fd7f](https://github.com/OctopusDeploy/cli/commit/672fd7f027d6fab1a122e107f0f00943acd5ce12))
* create listening tentacle ([#136](https://github.com/OctopusDeploy/cli/issues/136)) ([51ff9ec](https://github.com/OctopusDeploy/cli/commit/51ff9eccf8e9b51d3a92b5293656dc3ab2721935))
* create ssh deployment target ([a169d2e](https://github.com/OctopusDeploy/cli/commit/a169d2e0e898bfcf2cf2e749c002aa9ba9779269))
* deployment-target azure-web-app view ([fc639b4](https://github.com/OctopusDeploy/cli/commit/fc639b4b5d3a82538f26e0d90ac47939e8d3c200))
* deployment-target cloud-region view ([fc639b4](https://github.com/OctopusDeploy/cli/commit/fc639b4b5d3a82538f26e0d90ac47939e8d3c200))
* deployment-target listening-tentacle view ([fc639b4](https://github.com/OctopusDeploy/cli/commit/fc639b4b5d3a82538f26e0d90ac47939e8d3c200))
* deployment-target polling-tentacle view ([fc639b4](https://github.com/OctopusDeploy/cli/commit/fc639b4b5d3a82538f26e0d90ac47939e8d3c200))
* deployment-target ssh view ([fc639b4](https://github.com/OctopusDeploy/cli/commit/fc639b4b5d3a82538f26e0d90ac47939e8d3c200))
* deployment-target view ([fc639b4](https://github.com/OctopusDeploy/cli/commit/fc639b4b5d3a82538f26e0d90ac47939e8d3c200))
* deployment-target view ([fc639b4](https://github.com/OctopusDeploy/cli/commit/fc639b4b5d3a82538f26e0d90ac47939e8d3c200))
* target delete ([0d81e00](https://github.com/OctopusDeploy/cli/commit/0d81e003a7860fb565cd1c3db1f2879f96d4619c))
* target list  ([4ab66c2](https://github.com/OctopusDeploy/cli/commit/4ab66c2f8234f1e8cf77005a173b50287705c65a))
* tenant create, delete, tag ([8f70286](https://github.com/OctopusDeploy/cli/commit/8f702868e507c02a95fa26e89b02410fd25e0a24))
* tenant view ([7b2f7bd](https://github.com/OctopusDeploy/cli/commit/7b2f7bda5773ec54160f82ed6a6dfc8774ed2cac))
* worker delete ([#147](https://github.com/OctopusDeploy/cli/issues/147)) ([11c838c](https://github.com/OctopusDeploy/cli/commit/11c838cea45c4a02d7df7d092f81ec0b70a99bf0))
* worker list  ([b075cab](https://github.com/OctopusDeploy/cli/commit/b075cab4a1e6b03a1dce90af031aa8642045afb4))
* worker listening-tentacle create ([85f95db](https://github.com/OctopusDeploy/cli/commit/85f95dba761a40955e63ad65269a98081aaa5f6b))
* worker listening-tentacle create ([85f95db](https://github.com/OctopusDeploy/cli/commit/85f95dba761a40955e63ad65269a98081aaa5f6b))
* worker listening-tentacle list ([b075cab](https://github.com/OctopusDeploy/cli/commit/b075cab4a1e6b03a1dce90af031aa8642045afb4))
* worker listening-tentacle view ([c251e1c](https://github.com/OctopusDeploy/cli/commit/c251e1c192ec2106de165ab4e26986d77d8d5422))
* worker polling-tentacle list ([b075cab](https://github.com/OctopusDeploy/cli/commit/b075cab4a1e6b03a1dce90af031aa8642045afb4))
* worker polling-tentacle view ([c251e1c](https://github.com/OctopusDeploy/cli/commit/c251e1c192ec2106de165ab4e26986d77d8d5422))
* worker ssh create ([85f95db](https://github.com/OctopusDeploy/cli/commit/85f95dba761a40955e63ad65269a98081aaa5f6b))
* worker ssh list ([b075cab](https://github.com/OctopusDeploy/cli/commit/b075cab4a1e6b03a1dce90af031aa8642045afb4))
* worker ssh view ([c251e1c](https://github.com/OctopusDeploy/cli/commit/c251e1c192ec2106de165ab4e26986d77d8d5422))
* worker view ([c251e1c](https://github.com/OctopusDeploy/cli/commit/c251e1c192ec2106de165ab4e26986d77d8d5422))
* worker view ([#148](https://github.com/OctopusDeploy/cli/issues/148)) ([c251e1c](https://github.com/OctopusDeploy/cli/commit/c251e1c192ec2106de165ab4e26986d77d8d5422))


### Bug Fixes

* deployment-target list alias ([4bb2086](https://github.com/OctopusDeploy/cli/commit/4bb2086468e3931dde7156dce0bfdc9f259aaa8b))

## [0.5.0](https://github.com/OctopusDeploy/cli/compare/v0.4.0...v0.5.0) (2022-10-31)


### Features

* curl install ([e54dc3b](https://github.com/OctopusDeploy/cli/commit/e54dc3b98cb1cc79831bb5cbeb9b6d60cedb59a0))
* new selector ([564dcff](https://github.com/OctopusDeploy/cli/commit/564dcffae85d9eba1e64f7b0f59ebf3ab24e79a0))
* octopus logo on root help page ([1953205](https://github.com/OctopusDeploy/cli/commit/195320517d7879dabf3cf46f0692679c3d613338))
* project connect ([#122](https://github.com/OctopusDeploy/cli/issues/122)) ([017b958](https://github.com/OctopusDeploy/cli/commit/017b95862e220966dfce48823eb98a3b6abb8f74))
* project create ([#115](https://github.com/OctopusDeploy/cli/issues/115)) ([0a2e409](https://github.com/OctopusDeploy/cli/commit/0a2e40927a93344b76278e02db8dd18e0034f7d0))
* project delete ([#112](https://github.com/OctopusDeploy/cli/issues/112)) ([38039c3](https://github.com/OctopusDeploy/cli/commit/38039c33a7bb1250deac95092f347bc1f8bb6e13))
* project disconnect ([75ebb09](https://github.com/OctopusDeploy/cli/commit/75ebb09ea18594553c3c205239ff63ac61ba4198))
* project-group delete ([#126](https://github.com/OctopusDeploy/cli/issues/126)) ([18b36f6](https://github.com/OctopusDeploy/cli/commit/18b36f680e56a9d91d31658b208382da57f2d2c2))
* project-group list ([#125](https://github.com/OctopusDeploy/cli/issues/125)) ([d6e7f9f](https://github.com/OctopusDeploy/cli/commit/d6e7f9f40237610ebfd79954ce7e1aca424a5202))
* project-group view ([#127](https://github.com/OctopusDeploy/cli/issues/127)) ([ff00390](https://github.com/OctopusDeploy/cli/commit/ff00390e2ce2ba82f366914d493da42155abc90c))
* task wait ([#124](https://github.com/OctopusDeploy/cli/issues/124)) ([a4f925a](https://github.com/OctopusDeploy/cli/commit/a4f925a212fb398188de01a5eb5d9566b2f2e673))
* tenant connect ([#119](https://github.com/OctopusDeploy/cli/issues/119)) ([abc1b31](https://github.com/OctopusDeploy/cli/commit/abc1b31262d8a5a3b9677473a76e9feae620111a))
* tenant disconnect ([75ebb09](https://github.com/OctopusDeploy/cli/commit/75ebb09ea18594553c3c205239ff63ac61ba4198))
* tenant list ([#118](https://github.com/OctopusDeploy/cli/issues/118)) ([4b9c854](https://github.com/OctopusDeploy/cli/commit/4b9c8540842fb266b9d7ed7bf91898e023771a9d))

## [0.4.0](https://github.com/OctopusDeploy/cli/compare/v0.3.6...v0.4.0) (2022-10-10)


### Features

* add project list command ([d82273c](https://github.com/OctopusDeploy/cli/commit/d82273c4718e2bc71e8d62a85d85e26a05768191))
* add project view command ([bb77af9](https://github.com/OctopusDeploy/cli/commit/bb77af98cf6777925be45b51a22ee4b3e866c8ec))
* config list ([00942c3](https://github.com/OctopusDeploy/cli/commit/00942c33509c9f10ee71023d72cddf40efb2b0d2))
* runbook run and list ([70578df](https://github.com/OctopusDeploy/cli/commit/70578df0946a2eaa0414f3abb8a213cc99b9b916))

## [0.3.6](https://github.com/OctopusDeploy/cli/compare/v0.3.5...v0.3.6) (2022-09-30)


### Bug Fixes

* Add changed file before calling commit ([#101](https://github.com/OctopusDeploy/cli/issues/101)) ([552222a](https://github.com/OctopusDeploy/cli/commit/552222a16069a794e34892208f4146e2ed48633a))

## [0.3.5](https://github.com/OctopusDeploy/cli/compare/v0.3.4...v0.3.5) (2022-09-30)


### Bug Fixes

* Refactor git command code to powershell instead of bash ([#99](https://github.com/OctopusDeploy/cli/issues/99)) ([3d5a1a8](https://github.com/OctopusDeploy/cli/commit/3d5a1a8b75bd841fed21e163ff94eb0992b6167f))

## [0.3.4](https://github.com/OctopusDeploy/cli/compare/v0.3.3...v0.3.4) (2022-09-30)


### Bug Fixes

* PR creation is automated in the homebrew-taps repo so no need to create it here ([#97](https://github.com/OctopusDeploy/cli/issues/97)) ([ee03780](https://github.com/OctopusDeploy/cli/commit/ee03780ad54c915d6a78fbd6d0815d88cde2f232))

## [0.3.3](https://github.com/OctopusDeploy/cli/compare/v0.3.2...v0.3.3) (2022-09-30)


### Bug Fixes

* Fix issue when creating PR to update homebrew formula ([#95](https://github.com/OctopusDeploy/cli/issues/95)) ([03929eb](https://github.com/OctopusDeploy/cli/commit/03929ebd8a4f33c65ea8d0faf0e92449a0f4e74e))

## [0.3.2](https://github.com/OctopusDeploy/cli/compare/v0.3.1...v0.3.2) (2022-09-30)


### Bug Fixes

* Fix bug in deployment process causing homebrew update to fail ([#93](https://github.com/OctopusDeploy/cli/issues/93)) ([6c5ee67](https://github.com/OctopusDeploy/cli/commit/6c5ee678f1037415c4cbb7ab2605f9b3b20b780e))

## [0.3.1](https://github.com/OctopusDeploy/cli/compare/v0.3.0...v0.3.1) (2022-09-30)


### Bug Fixes

* Fix invalid syntax in script for pushing the updated homebrew formula ([#90](https://github.com/OctopusDeploy/cli/issues/90)) ([75e39a8](https://github.com/OctopusDeploy/cli/commit/75e39a84b8641f361e8fabaaa203426029b571ca))
* Sign rpm/deb packages as part of the creation process in goreleaser ([#92](https://github.com/OctopusDeploy/cli/issues/92)) ([b30498f](https://github.com/OctopusDeploy/cli/commit/b30498fb54e140f85056fc5dc271182cd584dd6f))

## [0.3.0](https://github.com/OctopusDeploy/cli/compare/v0.2.5...v0.3.0) (2022-09-29)


### Features

* accounts slugs ([#87](https://github.com/OctopusDeploy/cli/issues/87)) ([724f365](https://github.com/OctopusDeploy/cli/commit/724f365ba5bc908b24e69c21653c870dca345c68))
* package list ([28090f3](https://github.com/OctopusDeploy/cli/commit/28090f32bd907f80fdf0e455f35982f3a546395d))
* package upload/push ([28090f3](https://github.com/OctopusDeploy/cli/commit/28090f32bd907f80fdf0e455f35982f3a546395d))
* package versions ([28090f3](https://github.com/OctopusDeploy/cli/commit/28090f32bd907f80fdf0e455f35982f3a546395d))


### Bug Fixes

* octopus config set in interactive mode would fail for anything that wasn't already in the config file ([#83](https://github.com/OctopusDeploy/cli/issues/83)) ([0b43d8b](https://github.com/OctopusDeploy/cli/commit/0b43d8b1155e09955facb2b39024ea4aa7e32f2e))
* Update name of msi and add missing log argument to MSI call for Chocolatey ([7504b7d](https://github.com/OctopusDeploy/cli/commit/7504b7dd445146fdf2e8f35e1858135f2a56b2f0))

## [0.2.5](https://github.com/OctopusDeploy/cli/compare/v0.2.4...v0.2.5) (2022-09-20)


### Bug Fixes

* cli[#71](https://github.com/OctopusDeploy/cli/issues/71) - config system was leaking env vars into the config file when it shouldn't have  ([#80](https://github.com/OctopusDeploy/cli/issues/80)) ([e8edb32](https://github.com/OctopusDeploy/cli/commit/e8edb32247e4baa438e11238b61fddf7cb0ae595))

## [0.2.4](https://github.com/OctopusDeploy/cli/compare/v0.2.3...v0.2.4) (2022-09-16)


### Bug Fixes

* iron out the deployment process ([#78](https://github.com/OctopusDeploy/cli/issues/78)) ([fd59f84](https://github.com/OctopusDeploy/cli/commit/fd59f84b1be6b4c329583149577d540736646720))

## [0.2.3](https://github.com/OctopusDeploy/cli/compare/v0.2.2...v0.2.3) (2022-09-15)


### Bug Fixes

* releasenotes pickup in build flow, update go-octopusdeploy to 2.4.1 ([#76](https://github.com/OctopusDeploy/cli/issues/76)) ([4dc9550](https://github.com/OctopusDeploy/cli/commit/4dc955017ebbb12031830da37ab2d3ce3f3e3c78))

## [0.2.2](https://github.com/OctopusDeploy/cli/compare/v0.2.1...v0.2.2) (2022-09-13)


### Bug Fixes

* expand goreleaser workflow to build MSI and chocolatey packages ([1d86a77](https://github.com/OctopusDeploy/cli/commit/1d86a77ead003a199b3ee987c044dc45ae21e9ae))

## [0.2.1](https://github.com/OctopusDeploy/cli/compare/v0.2.0...v0.2.1) (2022-09-12)


### Features

* config file support ([#66](https://github.com/OctopusDeploy/cli/issues/66)) ([d911e0c](https://github.com/OctopusDeploy/cli/commit/d911e0caa04477ce677bd7e0652d06de18081c79))
* deploy release ([a2f85f0](https://github.com/OctopusDeploy/cli/commit/a2f85f0b357200d932cb4c0324678702b85c91e3))
* surveyext.DatePicker ([a2f85f0](https://github.com/OctopusDeploy/cli/commit/a2f85f0b357200d932cb4c0324678702b85c91e3))


### Bug Fixes

* Use survey's terminal.NewAnsiStdout to get colors to work in windows cmd.exe ([#68](https://github.com/OctopusDeploy/cli/issues/68)) ([01e02aa](https://github.com/OctopusDeploy/cli/commit/01e02aa39a442cdb896ef12715eadef94b150333)), closes [#67](https://github.com/OctopusDeploy/cli/issues/67)

## [0.2.0](https://github.com/OctopusDeploy/cli/compare/v0.1.0...v0.2.0) (2022-08-26)


### Features

* `release create`
* `release list`
* `release delete`
* `account <type> list commands` ([#41](https://github.com/OctopusDeploy/cli/issues/41)) ([5354118](https://github.com/OctopusDeploy/cli/commit/5354118066be9c31c83cd617f3ea50ff31f8b7ec))
* `account create` ([#47](https://github.com/OctopusDeploy/cli/issues/47)) ([11d67d1](https://github.com/OctopusDeploy/cli/commit/11d67d101217a2935a54bdb6534899c293d2a7a5))
* allow selection of space on command line ([0d42bc0](https://github.com/OctopusDeploy/cli/commit/0d42bc037572be9ce69cc135aa1dd51576666b36))
* CLI now prompts to select a space in interactive mode, or auto-selects if there is only one visible space. ([1f57272](https://github.com/OctopusDeploy/cli/commit/1f572720e5f797c45efe256cee919a2a37acf698))
* compatibility with legacy flags from the .NET CLI ([c439c2e](https://github.com/OctopusDeploy/cli/commit/c439c2e954f44b04b3975622d918d2bf3b6054bf))
* updated MultiSelectMap to return via generics ([d7d23d0](https://github.com/OctopusDeploy/cli/commit/d7d23d0b1cc4cc2d78a490a901c2e47d3fdf85f5))

### Bug Fixes

* --no-prompt and the CI environment check wasn't respected if the CLI wanted to prompt for the space name ([c75cf69](https://github.com/OctopusDeploy/cli/commit/c75cf69898504bcd074cda4a4bb153b096cbcff2))
* Activity spinner was showing over the top of the space selection prompt in interactive mode ([0d42bc0](https://github.com/OctopusDeploy/cli/commit/0d42bc037572be9ce69cc135aa1dd51576666b36))
* detection of terminal width when outputting tables ([10e1a9b](https://github.com/OctopusDeploy/cli/commit/10e1a9beec011249806e8506a3d44646f5fb8809))
* flag alias for --output-format and --outputFormat didn't work ([0d42bc0](https://github.com/OctopusDeploy/cli/commit/0d42bc037572be9ce69cc135aa1dd51576666b36))

## [0.1.0](https://github.com/OctopusDeploy/cli/compare/v0.0.3...v0.1.0) (2022-07-24)


### Features

* Add os env variable validation ([#19](https://github.com/OctopusDeploy/cli/issues/19)) ([9a577d1](https://github.com/OctopusDeploy/cli/commit/9a577d17f0fdfc365ffcd0b35f4a92c7d1571428))

## [0.0.3](https://github.com/OctopusDeploy/cli/compare/v0.0.2...v0.0.3) (2022-07-22)


### Bug Fixes

* signing ([#22](https://github.com/OctopusDeploy/cli/issues/22)) ([908484b](https://github.com/OctopusDeploy/cli/commit/908484b9561423528e1a3ffcc10f308a02c0b1e7))

## [0.0.2](https://github.com/OctopusDeploy/cli/compare/v0.0.1...v0.0.2) (2022-07-22)


### Bug Fixes

* package signing ([#20](https://github.com/OctopusDeploy/cli/issues/20)) ([d9ea487](https://github.com/OctopusDeploy/cli/commit/d9ea487220e4ba7a8dbeff98ace9b7680dd67679))

## [0.0.1](https://github.com/OctopusDeploy/cli/compare/v0.0.1...v0.0.1) (2022-07-22)


### Features

* init release ([4628209](https://github.com/OctopusDeploy/cli/commit/4628209371341bb7ac93d2ff4f590f09b7633816))


### Miscellaneous Chores

* change release please to simple mode ([#14](https://github.com/OctopusDeploy/cli/issues/14)) ([9615fa1](https://github.com/OctopusDeploy/cli/commit/9615fa19d45e9c4b4e73a1a7c14ed0072614d1b1))

## [0.0.1](https://github.com/OctopusDeploy/cli/compare/v1.2.0...v0.0.1) (2022-07-22)


### Features

* init release ([4628209](https://github.com/OctopusDeploy/cli/commit/4628209371341bb7ac93d2ff4f590f09b7633816))


### Miscellaneous Chores

* change release please to simple mode ([#14](https://github.com/OctopusDeploy/cli/issues/14)) ([9615fa1](https://github.com/OctopusDeploy/cli/commit/9615fa19d45e9c4b4e73a1a7c14ed0072614d1b1))
